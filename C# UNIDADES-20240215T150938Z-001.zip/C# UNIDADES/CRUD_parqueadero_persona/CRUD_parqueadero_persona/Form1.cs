﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using lib_logica_manzanas;


namespace CRUD_parqueadero_persona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            guardarPersona();
            limpiar();
            mostrar_registro();
            chbVehiculo.Checked = false;
            txtPlaca.Enabled = false;
            txtMarca.Enabled = false;
            txtColor.Enabled = false;
            label10.Enabled = false;
            label9.Enabled = false;
            label8.Enabled = false;


        }
        private void limpiar()
        {
            txtCedula.Text = "";
            txtNombre.Text = "";
            txtApellidos.Text = "";
            txtTelefono.Text = "";
            txtApto.Text = "";
            txtPersonas.Text = "";
            txtPlaca.Text = "";
            txtMarca.Text = "";
            txtColor.Text = "";
            lblApto.Text = "";
            lblNombre.Text = "";
            lblPlaca.Text = "";
            lblTelefono.Text = "";
            txtCedula.Enabled = true;
            btnBuscar.Enabled = true;
            btnLimpiar.Visible = true;

        }

        private void guardarPersona()
        {
             Cls_unidad objEmp = new Cls_unidad();
            try
            {
                objEmp.gsCedula = Convert.ToInt32(txtCedula.Text);
                objEmp.gsNombres = txtNombre.Text;
                objEmp.gsApellidos = txtApellidos.Text;
                objEmp.gsTelefono = txtTelefono.Text;
                objEmp.gsApartamento = txtApto.Text;
                objEmp.gsPersonas = txtPersonas.Text;
                objEmp.gsPlaca = txtPlaca.Text;
                objEmp.gsMarca = txtMarca.Text;
                objEmp.gsColor = txtColor.Text;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            if (!objEmp.guardarPersona())
            {
                MessageBox.Show(objEmp.gsError);
                return;
            }
            MessageBox.Show("se guardo correctamente el registro");
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (buscar())
            {
                btnEliminar.Enabled = true;
                btnActualizar.Enabled = true;
                btnBuscar.Enabled = false;
                txtCedula.Enabled = false;
                btnLimpiar.Visible = true;
                txtPlaca.Enabled = true;
                txtMarca.Enabled = true;
                txtColor.Enabled = true;
                label10.Enabled = true;
                label9.Enabled = true;
                label8.Enabled = true;



            }
            else
            {
                btnEliminar.Enabled = false;
                btnActualizar.Enabled = false;
                btnBuscar.Enabled = true;
                txtCedula.Enabled = true;

                txtPlaca.Enabled = false;
                txtMarca.Enabled = false;
                txtColor.Enabled = false;
                label10.Enabled = false;
                label9.Enabled = false;
                label8.Enabled = false;
                limpiar();
               
            }
            mostrar_registro();
        }

        private bool buscar()
        {
            Cls_unidad objEmp = new Cls_unidad();
            try
            {
                objEmp.gsCedula = Convert.ToInt32(txtCedula.Text);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            if (!objEmp.consultarPerById())
            {
                MessageBox.Show(objEmp.gsError);
                return false;
            }
            SqlDataReader readerP;
            readerP = objEmp.gsObjReader;

            if (readerP.HasRows)
            {
                readerP.Read();
                txtCedula.Text = readerP.GetInt32(0).ToString(); ;
                txtNombre.Text = readerP.GetString(1);
                txtApellidos.Text = readerP.GetString(2);
                txtTelefono.Text = readerP.GetString(3);
                txtApto.Text = readerP.GetString(4);
                txtPersonas.Text = readerP.GetString(5);
                txtPlaca.Text = readerP.GetString(6);
                txtMarca.Text = readerP.GetString(7);
                txtColor.Text = readerP.GetString(8);
                lblApto.Text = readerP.GetString(4);
                lblNombre.Text = readerP.GetString(1) + " " + readerP.GetString(2);
                lblTelefono.Text = readerP.GetString(3);
                lblPlaca.Text = readerP.GetString(6);
                readerP.Close();
                return true;
            }
            else
            {
                limpiar();
                MessageBox.Show(this, "el Registro no existe, intente nuevamente");
                txtCedula.Text = "";
                txtCedula.Focus();
                return false;
            }
        }  

               
            

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            btnBuscar.Enabled = true;
            txtCedula.Enabled = true;
            btnEliminar.Enabled = false;
            btnActualizar.Enabled = false;
            btnLimpiar.Visible = false;
            txtPlaca.Enabled = true;
            txtMarca.Enabled = true;
            txtColor.Enabled = true;
            label10.Enabled = false;
            label9.Enabled = false;
            label8.Enabled = false;
            chbVehiculo.Checked=false;
            limpiar();
            mostrar_registro();

        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            Cls_unidad objEmp = new Cls_unidad();
            try
            {
                objEmp.gsCedula = Convert.ToInt32(txtCedula.Text);
                objEmp.gsNombres = txtNombre.Text;
                objEmp.gsApellidos = txtApellidos.Text;
                objEmp.gsTelefono = txtTelefono.Text;
                objEmp.gsApartamento = txtApto.Text;
                objEmp.gsPersonas = txtPersonas.Text;
                objEmp.gsPlaca = txtPlaca.Text;
                objEmp.gsMarca = txtMarca.Text;
                objEmp.gsColor = txtColor.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            if (!objEmp.actualizarPer())
            {
                MessageBox.Show(objEmp.gsError);
                return;
            }
            MessageBox.Show("se actualizaron los datos del registro");
            limpiar();
            txtPlaca.Enabled = false;
            txtMarca.Enabled = false;
            txtColor.Enabled = false;
            label10.Enabled = false;
            label9.Enabled = false;
            label8.Enabled = false;
            mostrar_registro();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int idPersona;
            if (!int.TryParse(txtCedula.Text, out idPersona))
            {
                MessageBox.Show("El campo de cedula es válido.");
                return;
            }

            string nombreEmpleado = txtNombre.Text;
            string mensajeConfirmacion = $"¿Estás seguro que deseas eliminar el registro {nombreEmpleado}?";

            // Mostrar mensaje de confirmación
            DialogResult resultado = MessageBox.Show(mensajeConfirmacion, "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                // Llamar al método de eliminación de empleado en la lógica
                Cls_unidad objEmp = new Cls_unidad();
                objEmp.gsCedula = idPersona;
                if (!objEmp.EliminarPersona())
                {
                    MessageBox.Show(objEmp.gsError);
                    return;
                }

                MessageBox.Show("Se eliminó correctamente el registro.");
                limpiar();
                mostrar_registro();
            }
            else
            {
                MessageBox.Show("Eliminación de registro cancelada.");
            }
            chbVehiculo.Checked = false;
            txtPlaca.Enabled = false;
            txtMarca.Enabled = false;
            txtColor.Enabled = false;
            label10.Enabled = false;
            label9.Enabled = false;
            label8.Enabled = false;

        }

        private void chbVehiculo_CheckedChanged(object sender, EventArgs e)
        {
            if (chbVehiculo.Checked == true)
            {
                txtPlaca.Enabled = true;
                txtMarca.Enabled = true;
                txtColor.Enabled = true;
                label10.Enabled = true;
                label9.Enabled = true;
                label8.Enabled = true;
                btnActualizar.Enabled = true;
            }
            else
            {
                txtPlaca.Enabled = false;
                txtMarca.Enabled = false;
                txtColor.Enabled = false;
                label10.Enabled = false;
                label9.Enabled = false;
                label8.Enabled = false;
                btnActualizar.Enabled = false;
            }
        }

        private void txtCedula_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtPlaca.Enabled = true;
                txtMarca.Enabled = true;
                txtColor.Enabled = true;
                label10.Enabled = true;
                label9.Enabled = true;
                label8.Enabled = true;
                btnActualizar.Enabled = true;
                btnEliminar.Enabled = true;
                btnLimpiar.Visible = true;
                buscar();
                e.SuppressKeyPress = true; // Evita que se produzca el sonido de alerta al presionar Enter
            }
        }
        private bool mostrar_registro()
        {
            SqlConnection conexion = new SqlConnection("Data Source=LAPTOP-DJ558981;Initial Catalog=unidades;Integrated Security=True;");
            string listar = "select * from persona";
            SqlDataAdapter adaptar = new SqlDataAdapter(listar, conexion);
            DataTable dt = new DataTable();
            adaptar.Fill(dt);
            dataGridView3.DataSource = dt;
            return true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mostrar_registro();
        }
    }
}


