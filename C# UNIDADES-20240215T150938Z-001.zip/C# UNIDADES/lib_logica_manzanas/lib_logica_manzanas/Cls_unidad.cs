﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibConexionBD;

namespace lib_logica_manzanas
{
    public class Cls_unidad
    {
        private int cedula;
        private string nombres;
        private string apellidos;
        private string telefono;
        private string apartamento;
        private string personas;
        private string placa;
        private string marca;
        private string color;
        private string error;
        private SqlDataReader objReader;

        public Cls_unidad()
        {
            cedula = 0;
            nombres = string.Empty; ;
            apellidos = string.Empty; ;
            telefono = string.Empty; ;
            apartamento = string.Empty; ;
            personas = string.Empty; ;
            placa = string.Empty; ;
            marca = string.Empty; ;
            color = string.Empty; ;
            error = string.Empty; ;
           
        }

        public int gsCedula { get => cedula; set => cedula = value; }
        public string gsNombres { get => nombres; set => nombres = value; }
        public string gsApellidos { get => apellidos; set => apellidos = value; }
        public string gsTelefono { get => telefono; set => telefono = value; }
        public string gsApartamento { get => apartamento; set => apartamento = value; }
        public string gsPersonas { get => personas; set => personas = value; }
        public string gsPlaca { get => placa; set => placa = value; }
        public string gsMarca { get => marca; set => marca = value; }
        public string gsColor { get => color; set => color = value; }
        public string gsError { get => error; set => error = value; }
        public SqlDataReader gsObjReader { get => objReader; set => objReader = value; }

        public bool guardarPersona()
        {
            string sentencia = "EXECUTE Guardar " + cedula + ",'" + nombres + "','" + apellidos + "','" + telefono + "','" + apartamento + "','" + personas + "', '" + placa + "', '" + marca + "', '" + color + "' ";
            ClsConexion objConn = new ClsConexion();
            if (!objConn.EjecutarSentencia(sentencia, false))
            {
                error = objConn.Error;
                objConn = null;
                return false;
            }
            else
            {
                objConn = null;
                return true;
            }
        }

        public bool consultarPerById()
        {
            string sentencia = "EXECUTE BuscarPersona '" + cedula + "', '" +placa+ "' ";
            ClsConexion objConn = new ClsConexion();
            if (!objConn.Consultar(sentencia, false))
            {
                error = objConn.Error;
                objConn = null;
                return false;
            }
            else
            {
                gsObjReader = objConn.Reader;
                objConn = null;
                return true;
            }
        }


        public bool actualizarPer()
        {

            string sentencia = "EXECUTE Actualizar " + cedula + ",'" + nombres + "','" + apellidos + "','" + telefono + "','" + apartamento + "','" + personas + "', '" + placa + "', '" + marca + "', '" + color + "' ";
            ClsConexion objConn = new ClsConexion();
            if (!objConn.EjecutarSentencia(sentencia, false))
            {
                error = objConn.Error;
                objConn = null;
                return false;
            }
            else
            {
                objConn = null;
                return true;
            }
        }
        public bool EliminarPersona()
        {
            string sentencia = "EXECUTE Eliminar " + cedula + " ";
            ClsConexion objConn = new ClsConexion();
            if (!objConn.EjecutarSentencia(sentencia, false))
            {
                error = objConn.Error;
                objConn = null;
                return false;
            }
            else
            {
                objConn = null;
                return true;
            }
        }

    }
}
