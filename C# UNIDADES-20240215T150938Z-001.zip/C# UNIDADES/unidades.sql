USE [unidades]
GO

/****** Object:  Table [dbo].[persona]    Script Date: 23/06/2023 8:03:06 a.�m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[persona](
	[cedula] [int] NOT NULL,
	[nombres] [varchar](30) NOT NULL,
	[apellidos] [varchar](30) NOT NULL,
	[telefono] [varchar](20) NOT NULL,
	[apartamento] [varchar](5) NOT NULL,
	[personas] [varchar](5) NOT NULL,
	[placa] [varchar](10) NULL,
	[marca] [varchar](19) NULL,
	[color] [varchar](19) NULL,
PRIMARY KEY CLUSTERED 
(
	[cedula] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


